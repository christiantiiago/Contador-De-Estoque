USE frimesa;

-- Cria a tabela categorias
CREATE TABLE IF NOT EXISTS categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL UNIQUE
);

-- Insere categorias de exemplo na tabela categorias
INSERT IGNORE INTO categorias (nome)
VALUES
    ('Iogurtes'),
    ('Queijos'),
    ('Requeijão'),
    ('Manteiga'),
    ('Doce de Leite'),
    ('Creme de Leite'),
    ('Leite Condensado'),
    ('Presunto'),
    ('Mortadela'),
    ('Linguiça Calabresa'),
    ('Congelados');

-- Cria a tabela produtos
CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    camara VARCHAR(255) NOT NULL,
    bloco VARCHAR(255) NOT NULL,
    posicao_bloco VARCHAR(255) NOT NULL,
    nivel VARCHAR(255) NOT NULL,
    categoria_id INT NOT NULL,
    nome VARCHAR(255) NOT NULL,
    quantidade INT NOT NULL CHECK (quantidade >= 0),
    peso_liquido DECIMAL(10, 2) NOT NULL CHECK (peso_liquido >= 0),
    peso_bruto DECIMAL(10, 2) NOT NULL CHECK (peso_bruto >= 0),
    codigo_barras VARCHAR(255) NOT NULL UNIQUE,
    data_fabricacao DATE NOT NULL,
    data_validade DATE NOT NULL,
    foto_produto VARCHAR(255),
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE CASCADE
);

-- Cria a tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    profile_picture VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Adiciona índices para melhorar a performance das consultas
CREATE INDEX idx_categoria_id ON produtos(categoria_id);
CREATE INDEX idx_nome ON produtos(nome);
CREATE INDEX idx_camara ON produtos(camara);
