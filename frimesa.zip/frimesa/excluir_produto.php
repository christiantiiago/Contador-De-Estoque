<?php
session_start();
include 'db_connection.php';

// Verifica se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


$id = htmlspecialchars($_GET['id'] ?? '', ENT_QUOTES, 'UTF-8');

$sql = "DELETE FROM produtos WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->bindValue(':id', $id);

if ($stmt->execute()) {
    header('Location: visualizar_estoque.php?message=Produto excluído com sucesso');
    exit;
} else {
    echo "Erro ao excluir o produto.";
}

$conn = null;
?>
