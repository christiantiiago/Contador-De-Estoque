<?php
session_start();
include 'db_connection.php';

// Verifica se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$id = htmlspecialchars($_GET['id'] ?? '', ENT_QUOTES, 'UTF-8');

// Recupera as informações do produto
$stmt = $conn->prepare("SELECT * FROM produtos WHERE id = :id");
$stmt->bindValue(':id', $id);
$stmt->execute();
$produto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$produto) {
    echo "Produto não encontrado.";
    exit;
}

// Exibe o formulário de edição
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
    <link rel="stylesheet" href="css/editar.css"> <!-- Link para o CSS atualizado -->
</head>

<body>

<div class="container">
    <h1>Editar Produto</h1>

    <form action="atualizar_produto.php" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($produto['id']) ?>">

        <div class="mb-3">
            <label for="camara" class="form-label">Camara</label>
            <input type="text" class="form-control" id="camara" name="camara" value="<?= htmlspecialchars($produto['camara'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="bloco" class="form-label">Bloco</label>
            <input type="text" class="form-control" id="bloco" name="bloco" value="<?= htmlspecialchars($produto['bloco'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="posicao_bloco" class="form-label">Posição</label>
            <input type="text" class="form-control" id="posicao_bloco" name="posicao_bloco" value="<?= htmlspecialchars($produto['posicao_bloco'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="nivel" class="form-label">Nível</label>
            <input type="text" class="form-control" id="nivel" name="nivel" value="<?= htmlspecialchars($produto['nivel'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" class="form-control" id="nome" name="nome" value="<?= htmlspecialchars($produto['nome'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="quantidade" class="form-label">Quantidade</label>
            <input type="number" class="form-control" id="quantidade" name="quantidade" value="<?= htmlspecialchars($produto['quantidade'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="peso_liquido" class="form-label">Peso Líquido</label>
            <input type="number" step="0.01" class="form-control" id="peso_liquido" name="peso_liquido" value="<?= htmlspecialchars($produto['peso_liquido'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="peso_bruto" class="form-label">Peso Bruto</label>
            <input type="number" step="0.01" class="form-control" id="peso_bruto" name="peso_bruto" value="<?= htmlspecialchars($produto['peso_bruto'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="codigo_barras" class="form-label">ID Caixa</label>
            <input type="text" class="form-control" id="codigo_barras" name="codigo_barras" value="<?= htmlspecialchars($produto['codigo_barras'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="data_fabricacao" class="form-label">Data de Fabricação</label>
            <input type="date" class="form-control" id="data_fabricacao" name="data_fabricacao" value="<?= htmlspecialchars($produto['data_fabricacao'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="data_validade" class="form-label">Data de Validade</label>
            <input type="date" class="form-control" id="data_validade" name="data_validade" value="<?= htmlspecialchars($produto['data_validade'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label for="categoria" class="form-label">Categoria</label>
            <select class="form-control" id="categoria" name="categoria_id" required>
                <?php
                $categorias = $conn->query("SELECT * FROM categorias")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($categorias as $row) {
                    $selected = ($row['id'] == $produto['categoria_id']) ? ' selected' : '';
                    echo "<option value='" . htmlspecialchars($row['id']) . "'$selected>" . htmlspecialchars($row['nome']) . "</option>";
                }
                ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Atualizar Produto</button>
    </form>

</div> <!-- Fechar a div container -->

</body>
</html>

<?php
$conn = null;
?>
