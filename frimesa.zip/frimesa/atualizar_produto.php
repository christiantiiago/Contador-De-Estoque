<?php
session_start();
include 'db_connection.php';

// Verifica se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_connection.php';

// Sanitização dos dados recebidos
$id = htmlspecialchars($_POST['id'] ?? '', ENT_QUOTES, 'UTF-8');
$camara = htmlspecialchars($_POST['camara'] ?? '', ENT_QUOTES, 'UTF-8');
$bloco = htmlspecialchars($_POST['bloco'] ?? '', ENT_QUOTES, 'UTF-8');
$posicao_bloco = htmlspecialchars($_POST['posicao_bloco'] ?? '', ENT_QUOTES, 'UTF-8');
$nivel = htmlspecialchars($_POST['nivel'] ?? '', ENT_QUOTES, 'UTF-8');
$nome = htmlspecialchars($_POST['nome'] ?? '', ENT_QUOTES, 'UTF-8');
$quantidade = htmlspecialchars($_POST['quantidade'] ?? '', ENT_QUOTES, 'UTF-8');
$peso_liquido = htmlspecialchars($_POST['peso_liquido'] ?? '', ENT_QUOTES, 'UTF-8');
$peso_bruto = htmlspecialchars($_POST['peso_bruto'] ?? '', ENT_QUOTES, 'UTF-8');
$codigo_barras = htmlspecialchars($_POST['codigo_barras'] ?? '', ENT_QUOTES, 'UTF-8');
$data_fabricacao = htmlspecialchars($_POST['data_fabricacao'] ?? '', ENT_QUOTES, 'UTF-8');
$data_validade = htmlspecialchars($_POST['data_validade'] ?? '', ENT_QUOTES, 'UTF-8');
$categoria_id = htmlspecialchars($_POST['categoria_id'] ?? '', ENT_QUOTES, 'UTF-8');

// Atualiza o produto no banco de dados
$sql = "UPDATE produtos SET
            camara = :camara,
            bloco = :bloco,
            posicao_bloco = :posicao_bloco,
            nivel = :nivel,
            nome = :nome,
            quantidade = :quantidade,
            peso_liquido = :peso_liquido,
            peso_bruto = :peso_bruto,
            codigo_barras = :codigo_barras,
            data_fabricacao = :data_fabricacao,
            data_validade = :data_validade,
            categoria_id = :categoria_id
        WHERE id = :id";

$stmt = $conn->prepare($sql);

$stmt->bindValue(':camara', $camara);
$stmt->bindValue(':bloco', $bloco);
$stmt->bindValue(':posicao_bloco', $posicao_bloco);
$stmt->bindValue(':nivel', $nivel);
$stmt->bindValue(':nome', $nome);
$stmt->bindValue(':quantidade', $quantidade);
$stmt->bindValue(':peso_liquido', $peso_liquido);
$stmt->bindValue(':peso_bruto', $peso_bruto);
$stmt->bindValue(':codigo_barras', $codigo_barras);
$stmt->bindValue(':data_fabricacao', $data_fabricacao);
$stmt->bindValue(':data_validade', $data_validade);
$stmt->bindValue(':categoria_id', $categoria_id);
$stmt->bindValue(':id', $id);

try {
    $stmt->execute();
    // Redireciona para a página de visualização de estoque após a atualização
    header('Location: visualizar_estoque.php');
    exit();
} catch (PDOException $e) {
    echo "Erro ao atualizar produto: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}

$conn = null;
