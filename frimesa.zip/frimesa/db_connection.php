<?php
$servername = "localhost";
$port = "3306"; // Deixe vazio se não precisar especificar a porta
$username = "frimesa"; // Usuário correto
$password = "bcT8yY5d4Cw22ja"; // Senha correta
$dbname = "frimesa";

try {
    // Cria uma instância PDO
    $dsn = "mysql:host=$servername;dbname=$dbname" . ($port ? ";port=$port" : "");
    $conn = new PDO($dsn, $username, $password);
    
    // Definindo o modo de erro para exceções
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Opcional: Definir o charset
    $conn->exec("set names utf8mb4");
    
    // Confirmando a conexão
    echo "Conexão bem-sucedida!";
} catch (PDOException $e) {
    // Exibindo mensagem de erro
    echo "Erro de conexão: " . $e->getMessage();
}
?>
